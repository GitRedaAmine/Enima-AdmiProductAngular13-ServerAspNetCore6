
# DZ_cities
communes et wilaya d'Algérie en arabe et en français en format sql,json,cvs et xls

